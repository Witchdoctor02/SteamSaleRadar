# 세일레이더 안드로이드 앱

세일레이더 웹 앱(`app/src/main/assets/index.html`)을 안드로이드 앱으로 감싼 프로젝트입니다.

- 찜 목록, 가격 기록 그래프, 다음 할인 예측, 세일 캘린더를 앱 안에서 그대로 쓸 수 있어요
- 할인 알림이 **휴대폰 시스템 알림**으로 와요. 알림을 누르면 해당 게임 화면이 열려요
- Android 8.0(API 26) 이상에서 동작해요

## APK 만드는 방법

### 방법 1. GitHub에서 자동 빌드 (PC에 아무것도 설치하지 않아도 돼요)

1. GitHub에서 새 저장소를 만들어요 (Private도 괜찮아요).
2. 이 폴더의 파일을 모두 올려요. 숨김 폴더인 `.github` 폴더도 꼭 함께 올려야 해요.
   - 웹에서 올릴 때는 "uploading an existing file"에 폴더째 끌어다 놓으세요.
   - git을 쓴다면:
     ```
     git init && git add . && git commit -m "init"
     git branch -M main
     git remote add origin https://github.com/<내아이디>/SaleRadar.git
     git push -u origin main
     ```
3. 저장소의 **Actions** 탭으로 가면 "Build APK"가 자동으로 실행돼요. 약 3~5분 걸려요.
4. 빌드가 끝나면 실행 기록을 열고, 아래 **Artifacts**에서 `SaleRadar-apk`를 내려받아요.
   - 받은 zip 파일의 압축을 풀면 `SaleRadar.apk`가 들어 있어요.

### 방법 2. Android Studio에서 빌드

1. Android Studio에서 **File > Open**으로 이 폴더를 열어요.
2. Gradle 동기화가 끝날 때까지 기다려요. 처음에는 필요한 파일을 자동으로 내려받아요.
3. 메뉴에서 **Build > Build App Bundle(s) / APK(s) > Build APK(s)**를 눌러요.
4. 만들어진 APK는 `app/build/outputs/apk/` 아래에 있어요.

터미널에서 빌드하려면 Android SDK와 JDK 17 이상이 필요해요. 준비되어 있다면 아래 명령으로 빌드할 수 있어요.

```
./gradlew assembleRelease
```

만들어진 APK는 `app/build/outputs/apk/release/app-release.apk`예요.

## 휴대폰에 설치하기

1. APK 파일을 휴대폰으로 옮겨요. 카톡 나에게 보내기, 구글 드라이브, USB 등 아무 방법이나 괜찮아요.
2. 파일을 눌러 설치해요.
3. "출처를 알 수 없는 앱" 경고가 뜨면, 그 파일을 연 앱(파일 관리자, 크롬 등)에 설치를 허용해 주세요.
4. 앱을 처음 열면 알림 권한을 물어봐요. **허용**을 눌러야 할인 알림을 받을 수 있어요.

## 알아 둘 점

- 이 APK는 **디버그 키로 서명**되어 있어요. 내 휴대폰에 직접 설치하는 용도로는 문제없어요.
- Play 스토어에 올리려면 본인의 서명 키를 만들고 `app/build.gradle.kts`의 `signingConfig`를 바꿔야 해요.
- 게임 목록과 가격 기록은 데모용 샘플 데이터예요.
- 알림은 **앱을 열었을 때** 조건을 확인해서 보내요.
- 실제 Steam 가격을 가져오고, 앱이 꺼져 있을 때도 알림을 보내려면 가격을 주기적으로 확인하는 서버와 푸시 알림(FCM 등)이 필요해요.

## 웹 앱을 수정했다면

`app/src/main/assets/index.html` 파일만 바꾼 다음, 다시 빌드하면 돼요.
