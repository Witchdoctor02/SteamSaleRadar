plugins {
    id("com.android.application")
}

android {
    namespace = "com.saleradar.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.saleradar.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // 개인 설치용: 디버그 키로 서명해서 바로 설치 가능한 release APK를 만듭니다.
            // Play 스토어에 올릴 때는 본인 키로 바꾸세요.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
