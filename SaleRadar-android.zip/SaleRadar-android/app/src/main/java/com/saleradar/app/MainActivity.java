package com.saleradar.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * 세일레이더 웹 앱(assets/index.html)을 WebView로 띄우는 화면.
 * 웹 앱의 알림은 JS 브리지(window.Android)를 통해 안드로이드 시스템 알림으로 보냅니다.
 */
public class MainActivity extends Activity {

    private static final String CHANNEL_ID = "sale_alerts";
    private static final String PERM_NOTIF = "android.permission.POST_NOTIFICATIONS";
    private static final String BASE_URL = "file:///android_asset/index.html";

    private WebView web;
    private int notifId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createChannel();

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#1b2838"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);   // 찜 목록·알림 설정 저장(localStorage)
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme();
                // 외부 링크(https)는 기기 브라우저로 엽니다.
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                    return true;
                }
                return false;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            String gid = gameIdFrom(getIntent());
            web.loadUrl(gid != null ? BASE_URL + "#game-" + gid : BASE_URL);
        }

        askNotificationPermission();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String gid = gameIdFrom(intent);
        if (gid != null) web.evaluateJavascript("location.hash='game-" + gid + "'", null);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /* ---------- 알림 ---------- */

    private static String gameIdFrom(Intent i) {
        if (i == null) return null;
        String gid = i.getStringExtra("gid");
        return (gid != null && gid.matches("\\d+")) ? gid : null;
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription(getString(R.string.channel_desc));
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private boolean canNotify() {
        return Build.VERSION.SDK_INT < 33
                || checkSelfPermission(PERM_NOTIF) == PackageManager.PERMISSION_GRANTED;
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !canNotify()) {
            requestPermissions(new String[]{PERM_NOTIF}, 1);
        }
    }

    /** 웹 앱에서 window.Android 로 호출하는 함수들 */
    private class Bridge {
        @JavascriptInterface
        public boolean canNotify() {
            return MainActivity.this.canNotify();
        }

        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(MainActivity.this::askNotificationPermission);
        }

        @JavascriptInterface
        public void showNotification(String title, String body, String gid) {
            if (!MainActivity.this.canNotify()) return;
            int id = notifId++;
            Intent open = new Intent(MainActivity.this, MainActivity.class);
            open.putExtra("gid", gid);
            open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(MainActivity.this, id, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            Notification n = new Notification.Builder(MainActivity.this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_stat_notify)
                    .setColor(Color.parseColor("#a4d007"))
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            getSystemService(NotificationManager.class).notify(id, n);
        }
    }
}
